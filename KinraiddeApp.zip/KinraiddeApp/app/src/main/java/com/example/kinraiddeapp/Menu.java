package com.example.kinraiddeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;



import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;

import android.os.Bundle;
import android.util.Log;

import android.view.View;

import android.widget.Button;

import android.widget.TextView;
import android.widget.EditText;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import android.widget.Toast;

import java.util.Random;

public class Menu extends AppCompatActivity {


    String foodlist[] = {            "กระเพาะปลา",            "กระเพาะปลาตุ๋นน้ำแดง่",            "ก๋วยจั๊บ",            "ก๋วยจั๊บญวณ",            "ก๋วยเตี๋ยวแขก",            "ก๋วยเตี๋ยวคั่วไก่",            "ก๋วยเตี๋ยวหลอด",            "กุ้งแช่น้ำปลา",            "กุ้งทอดกระเทียมพริกไทย",
            "กุ้งนางนึ่งนมสด",            "แกงกะหรี่ไก่",            "แกงกะหรี่หมู",            "แกงขี้เหล็ก",            "แกงเขียวหวานไก่",            "แกงเขียวหวานปลาดุก",            "แกงเขียวหวานลูกชิ้นปลากราย",            "แกงส้มปลาช่อนผักบุ้ง",            "แกงส้มปลาแปะซะ",
            "แกงส้มผักกะเฉด-ปลา",            "แกงส้มผักบุ้งปลาช่อน่",            "แกงส้มผักรวม",            "แกงหมูเทโพ",            "แกงเหลืองมะละกอกุ้ง",            "ยำหมูย่าง",            "ยำหอยแมลงภู่",            "เย็นตาโฟ",            "ราดหน้าบะหมี่กรอบ",
            "สลัดปลาทูน่า",            "สัมปะนี",            "สาคูไส้หมู",            "สำลีหอม",            "สุกี้กุ้ง ไม่ใส่วุ้นเส้น",            "สุกี้ไก่ ไม่ใส่วุ้นเส้น",            "สุกี้น้ำไก่",            "สุกี้หมู ไม่ใส่วุ้นเส้น",            "สุกี้แห้งทะเล",            "เส้นก๋วยเตี๋ยวผัดขี้เมา",
            "ผัดเผ็ดปลาทอดกรอบ",            "ผัดเผ็ดมะเขือหม",            "ผัดพริกแกงหมูหน่อไม้",            "ผัดพริกขิงหมูถั่วฝักยาว",            "ผัดฟักทองใส่ไข่",            "ผัดมะเขือยาวหมูสับ",           "ผัดมักกะโรนีกุ้ง",            "ผัดมักกะโรนีหมู",
            "ผัดยอดมะระน้ำมันหอย",            "ผัดวุ้นเส้นใส่ไข่",            "พะแนงไก",            "พะโล้",            "มักกะโรนีผัดกุ้ง",            "เมี่ยงก๋วยเตี๋ยว",            "เมี่ยงคำ",            "ยำกุนเชียง",            "ยำขนมจีน",            "ยำไข่ต้ม"    };

    String drinklist[] = {"น้ำกระเจี๊ยบ",            "น้ำอัดลม",            "น้ำมะเขือเทศ",            "น้ำมะตูม",            "น้ำมะนาว",            "น้ำมะพร้าว",            "น้ำลำใย",            "น้ำส้มคั้น",            "น้ำสับปะรด",            "น้ำองุ่น",            "น้ำอ้อย",
            "รูทเบียร์่",            "วอดก้า",            "วิสกี้",            "บรั่นดี",            "น้ำขิง",            "น้ำจับเลี้ยง",            "น้ำชาเขียว",            "น้ำชาเขียวน้ำผึ้ง",            "น้ำตาลทราย่",            "ชาเย็น",            "ชามะนาว"};

    String dessertlist[] = {"คุ้กกี้ข้าวโอ๊ต",            "กระทงทองไส้ข้าวโพด",            "กระทงทองไส้ไก่",            "กระยาสารท",            "กล้วยคลุกมะพร้าว",            "ขนมปังอบกรอบ",            "ขนมปังไส้กรอก",            "ขนมปังไส้หมูหยอง",
            "ขนมหม้อแกง",            "ขนมขี้หนู",            "ขนมเข่ง",            "ขนมครก",            "ขนมตาล",            "ขนมถั่วแปป",            "ขนมเทียน",            "ขนมบ้าบิ่น",            "ข้าวแตนราดน้ำตาล",            "ข้าวโพดต้ม",
            "ข้าวเม่าทอด",            "ข้าวเหนียวมูลกะทิ",};






    private static final String TAG = "SettingActivity";

    TextView name;
    SharedPreferences sp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        int fooda = new Random().nextInt(foodlist.length);
        final String foodrandom = (foodlist[fooda]);

        int drinka = new Random().nextInt(drinklist.length);
        final String drinkrandom = (drinklist[drinka]);

        int desserta = new Random().nextInt(dessertlist.length);
        final String dessertrandom = (dessertlist[desserta]);



        TextView textView4 = (TextView)findViewById(R.id.textView4);
        textView4.setText(foodrandom +"  "+ drinkrandom +"  "+ dessertrandom);

//      show popup comment
        Button fab = (Button) findViewById(R.id.comment);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAddItemDialog(Menu.this);
            }
        });

// show Username
        name = (TextView)findViewById(R.id.name);
        sp = getApplication().getSharedPreferences("PREFNAME", MODE_PRIVATE);
        String Username=sp.getString("edtUserName", "");
        name.setText(Username);

//        link to food page
        Button food = (Button) findViewById(R.id.food);
        food.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this, Food.class);
                startActivity(intent);
            }
        });

//        link to drink page
        Button drink = (Button) findViewById(R.id.drink);
        drink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this, Drink.class);
                startActivity(intent);
            }
        });

//        link to desert page
        Button desert = (Button) findViewById(R.id.desert);
        desert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this, Dessert.class);
                startActivity(intent);
            }
        });


    }
//      get comment to fire base
    private void showAddItemDialog(Context c) {

        final EditText taskEditText = new EditText(c);
        AlertDialog dialog = new AlertDialog.Builder(c)
                .setTitle("แสดงความคิดเห็น")
                .setView(taskEditText)
                .setPositiveButton("ส่งความคิดเห็น", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        String task = String.valueOf(taskEditText.getText());
                        Toast.makeText(Menu.this,"ส่งความคิดเห็นแล้ว",Toast.LENGTH_LONG).show();


                        FirebaseDatabase mDatabase = FirebaseDatabase.getInstance();
                        DatabaseReference mDbRef = mDatabase.getReference("Feedback/comment/");
                        mDbRef.setValue(task).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.d(TAG, e.getLocalizedMessage());

                            }
                        });
                    }
                })
                .setNegativeButton("ยกเลิก", null)
                .create();
        dialog.show();
    }


    public void onBackPressed() {
//      link to exit

        AlertDialog.Builder dialog1 = new AlertDialog.Builder(this);
        dialog1.setTitle("ออก");
        dialog1.setIcon(R.mipmap.logoapp);
        dialog1.setCancelable(true);
        dialog1.setMessage("คุณต้องการออกจากแอพพิเคชั่น?");
        dialog1.setPositiveButton("ใช่", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });

        dialog1.setNegativeButton("ไม่ใช่", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog1, int which) {
                dialog1.cancel();
            }
        });

        dialog1.show();
    }
}
