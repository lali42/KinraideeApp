package com.example.kinraiddeapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import java.util.Random;
import java.util.ArrayList;
import android.widget.Toast;
import java.util.HashMap;

public class Drink extends AppCompatActivity {

    // List view
    private ListView lv;

    // Listview Adapter
    ArrayAdapter<String> adapter;

    // Search EditText
    EditText inputSearch;


    // ArrayList for Listview
    ArrayList<HashMap<String, String>> productList;

    // Listview Data

    String products[] = {"น้ำกระเจี๊ยบ	1 แก้ว	120 กิโลแคลอรี่",
            "น้ำอัดลม	                1 แก้ว	100 กิโลแคลอรี่",
            "น้ำมะเขือเทศ	            1 แก้ว	48 กิโลแคลอรี่",
            "น้ำมะตูม	                1 แก้ว	120 กิโลแคลอรี่",
            "น้ำมะนาว	                1 แก้ว	100 กิโลแคลอรี่",
            "น้ำมะพร้าว	            1 แก้ว	120 กิโลแคลอรี่",
            "น้ำลำใย	                1 แก้ว	100 กิโลแคลอรี่",
            "น้ำส้มคั้น	                1 แก้ว	160 กิโลแคลอรี่",
            "น้ำสับปะรด	            1 แก้ว	125 กิโลแคลอรี่",
            "น้ำองุ่น	                1 แก้ว	112 กิโลแคลอรี่",
            "น้ำอ้อย	                 1 แก้ว	240 กิโลแคลอรี่",
            "รูทเบียร์	                 1 แก้ว	105 กิโลแคลอรี่",
            "วอดก้า	                 1 cc	2 กิโลแคลอรี่",
            "วิสกี้	                     1 cc	2 กิโลแคลอรี่",
            "บรั่นดี	                 1 cc	2 กิโลแคลอรี่",
            "น้ำขิง     	            1 กล่อง	60 กิโลแคลอรี่",
            "น้ำจับเลี้ยง	            1 แก้ว	100 กิโลแคลอรี่",
            "น้ำชาเขียว	            1 กล่อง	70 กิโลแคลอรี่",
            "น้ำชาเขียวน้ำผึ้ง          1 กล่อง	70 กิโลแคลอรี่",
            "น้ำตาลทราย	            1 ช้อนชา	20 กิโลแคลอรี่",
            "น้ำนมข้าวโพด               1 แก้ว	80 กิโลแคลอรี่",
            "น้ำผลไม้รวม            1 กล่อง	100 กิโลแคลอรี่",
            "น้ำผักรวม	            1 กล่อง	90 กิโลแคลอรี่",
            "น้ำฝรั่ง 	                 1 กล่อง	100 กิโลแคลอรี่",
            "กาแฟเย็น	                 200 ml	317 กิโลแคลอรี่",
            "โกโก้เย็น	                200 ml	334 กิโลแคลอรี่",
            "ชาเขียวนมเย็น           200 ml	319 กิโลแคลอรี่",
            "ชานมเย็น 	            200 ml	319 กิโลแคลอรี่",
            "นมเย็น	                200 ml	425 กิโลแคลอรี่",
            "โอเลี้ยง	                200 ml	103 กิโลแคลอรี่",
            "ชาเย็น	                200 ml	100 กิโลแคลอรี่",
            "ชามะนาว	                200 ml	100 กิโลแคลอรี่"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink);

        Button arrow = (Button)findViewById(R.id.arrow);
        arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Drink.this, Menu.class);
                Toast.makeText(Drink.this, "กลับหน้าเมนูหลัก", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });



//      random
        int idx = new Random().nextInt(products.length);
        final String random = (products[idx]);

        Button button2 = (Button)findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                TextView textView = (TextView)findViewById(R.id.textView);
                textView.setText(random);

                Toast.makeText(Drink.this, "ทาน" + random + "ให้อร่อย", Toast.LENGTH_LONG).show();
            }
        });

        lv = (ListView) findViewById(R.id.list_view);
        inputSearch = (EditText) findViewById(R.id.inputSearch);

        // Adding items to listview
        adapter = new ArrayAdapter<String>(this, R.layout.list_item, R.id.product_name, products);
        lv.setAdapter(adapter);

        inputSearch.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                // When user changed the Text
                Drink.this.adapter.getFilter().filter(cs);
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                          int arg3) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable arg0) {
                // TODO Auto-generated method stub
            }
        });
    }
}
