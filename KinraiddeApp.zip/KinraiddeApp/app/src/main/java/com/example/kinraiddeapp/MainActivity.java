package com.example.kinraiddeapp;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
    final String PREFNAME = "SamplePreferences";
    final String USERNAME = "UserName";

    EditText edtUserName;
    SharedPreferences.Editor editor;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtUserName = (EditText)findViewById(R.id.edtUserName);
        SharedPreferences sp = getApplicationContext().getSharedPreferences("PREFNAME", MODE_PRIVATE);
        editor = sp.edit();

        edtUserName.setText(sp.getString(USERNAME, ""));
        edtUserName.addTextChangedListener(new TextWatcher() {
            public void onTextChanged(CharSequence s, int start, int before, int count) { }
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            public void afterTextChanged(Editable s) {
                editor.putString(USERNAME, s.toString());
            }
        });


        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String UserName = edtUserName.getText().toString();
                editor.putString("edtUserName", UserName);
                editor.commit();
                Intent intent = new Intent(MainActivity.this, Menu.class);
                startActivity(intent);
                finish();
            }
        });


    }
}
